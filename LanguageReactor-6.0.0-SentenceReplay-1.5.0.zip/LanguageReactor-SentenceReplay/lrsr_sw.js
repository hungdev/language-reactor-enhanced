importScripts('background.min.js', 'lrsr_background.js');
